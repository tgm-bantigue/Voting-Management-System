-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 12, 2018 at 05:42 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `votingsystemdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `Name` varchar(100) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`Name`, `Username`, `Password`) VALUES
('Iam the Admin', 'qwe', '123');

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

CREATE TABLE `candidates` (
  `Position` varchar(80) NOT NULL,
  `LRN` int(12) NOT NULL,
  `LastName` varchar(80) NOT NULL,
  `FirstName` varchar(80) NOT NULL,
  `MiddleName` varchar(80) NOT NULL,
  `Year_Section` varchar(50) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `ContactNo` varchar(20) NOT NULL,
  `Votes` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`Position`, `LRN`, `LastName`, `FirstName`, `MiddleName`, `Year_Section`, `Address`, `ContactNo`, `Votes`) VALUES
('President', 123, 'Robles', 'Mart', 'R', 'BSIT 3G-G1', 'Pulilan Bulacan', '99999', '0'),
('President', 0, 'Guillermo', 'Genesis', 'G', 'BSIT 3G-G1', 'Malolos Bulacan', '99999', '0'),
('Vice President', 0, 'Reyes', 'Crisostoma', 'C', 'BSIT 3G-G1', 'Malolos Bulacan', '99999', '0'),
('Vice President', 0, 'Reyes', 'Wency', 'C', 'BSIT 3G-G1', 'Malolos Bulacan', '99999', '0'),
('Secretary', 0, 'Batigue', 'Serena', 'B', 'BSIT 3G-G1', 'Malolos Bulacan', '99999', '0'),
('Secretary', 0, 'Claveria', 'Kel', 'B', 'BSIT 3G-G1', 'Calumplit Bulacan', '99999', '0'),
('P.R.O.', 0, 'Reyna', 'Diane', 'B', 'BSIT 3G-G1', 'Calumplit Bulacan', '99999', '0'),
('P.R.O.', 111, 'Dimaguiba', 'Lorna', 'Reyes', 'Section 5', 'Pulilan Malolos, Bulacan', '935353535', '0'),
('Treasurer', 123456789, 'Alapag', 'Jimmy', 'Santos', 'BSIT 3G-G1', 'Pulilan Malolos, Bulacan', '0987', '0'),
('Treasurer', 987654321, 'Domingo', 'Ferdinand', 'Magellan', 'BSIT 3G-G2', '', '', '0'),
('Asst. Treasurer', 54321, 'Gomez', 'Jose', 'Burgos', 'BSIT 3G-G1', 'Baliwag, Bulacan', '7654', '0'),
('Asst. Treasurer', 5678, 'Balkman', 'Ronaldo', 'Slaughter', 'BSIT 3G-G1', 'Brgy. Tibay', '3456', '0'),
('President', 2015166817, 'Bantigue', 'Tristan Glenn', 'M', 'ACT 2L-G2', 'Bulihan Malolos, Bulacan', '09351390471', '0'),
('Auditor', 765, 'Sotto', 'Vic', 'T', 'Section EB', 'Broadway Centrum', '567', '0'),
('Auditor', 432, 'Bang', 'Ryan', 'S', 'Section ST', 'Seoul, Korea', '234', '0');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `LRN` int(12) NOT NULL,
  `LastName` varchar(100) NOT NULL,
  `FirstName` varchar(100) NOT NULL,
  `MiddleName` varchar(100) NOT NULL,
  `Year_Section` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`LRN`, `LastName`, `FirstName`, `MiddleName`, `Year_Section`) VALUES
(2147483647, 'bantz', 'glentot', 'middlemoto', 'bsit3gg1'),
(123456789, 'bantz', 'glentot', 'middlemoto', 'bsit3gg1'),
(321, 'Bantigue', 'Tristan Glenn', 'Maturingan', 'BSIT 3G-G1'),
(1, 'Alexander', 'Michael', 'Roque', 'Ruby'),
(2, 'Chico', 'Jonathan', 'Hernandez', 'Ruby'),
(2, 'Ginto', 'Shaira', 'Inpo', 'Ruby'),
(3, 'Camus', 'David', 'Abunto', 'Ruby'),
(4, 'Zulueta', 'Paul', 'Biteng', 'Emerald'),
(5, 'Abaya', 'Jay', 'Jane', 'Emerald'),
(6, 'Fernandez', 'Chistopher', 'Amir', 'Emerald'),
(7, 'Magtoto', 'Renz', 'Amir', 'Emerald');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
