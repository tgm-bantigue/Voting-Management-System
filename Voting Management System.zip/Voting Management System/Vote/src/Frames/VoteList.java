package Frames;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class VoteList extends javax.swing.JFrame {
    public static Statement s = null ;
    public static java.sql.Connection con = null;
    public static ResultSet rs;

    public VoteList() {
        initComponents();
    }
    
     public static java.sql.Connection getCon(){
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/votingsystemdb", "root", "");
            System.out.println("Connected to database!");
        } catch (SQLException ex) {
            Logger.getLogger(Frames.Connection.class.getName()).log(Level.SEVERE, null, ex);
        }
        return con;
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        audtb = new javax.swing.JTextField();
        prestb = new javax.swing.JTextField();
        vptb = new javax.swing.JTextField();
        sectb = new javax.swing.JTextField();
        trestb = new javax.swing.JTextField();
        asttb = new javax.swing.JTextField();
        protb = new javax.swing.JTextField();
        donebtn = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        backbtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBackground(new java.awt.Color(0, 204, 0));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 10)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("____________________________________________________");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel4.setText("CITY OF MALOLOS");

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setText("MARCELO H. DEL PILAR NATIONAL HIGHSCHOOL ");

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel5.setText("STUDENT COUNCIL");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Materials/MHPNHS6 - Copy.jpg"))); // NOI18N
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(106, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(36, 36, 36)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(jLabel2)
                    .addComponent(jLabel4)
                    .addComponent(jLabel3)
                    .addComponent(jLabel5))
                .addGap(61, 61, 61))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(11, 11, 11)
                        .addComponent(jLabel5)))
                .addContainerGap())
        );

        jPanel5.setBackground(new java.awt.Color(255, 255, 153));
        jPanel5.setBorder(new javax.swing.border.MatteBorder(null));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel15.setFont(new java.awt.Font("Times New Roman", 0, 10)); // NOI18N
        jLabel15.setText("__________________________________________________");
        jLabel15.setToolTipText("");
        jPanel5.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 50, 270, 31));

        jLabel19.setFont(new java.awt.Font("Times New Roman", 1, 19)); // NOI18N
        jLabel19.setText("CANDIDATES YOU'VE VOTED");
        jLabel19.setAutoscrolls(true);
        jPanel5.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 40, -1, -1));

        jLabel20.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel20.setText("VICE PRESIDENT:");
        jLabel20.setAutoscrolls(true);
        jPanel5.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, -1, -1));

        jLabel21.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel21.setText("SECRETARY:");
        jLabel21.setAutoscrolls(true);
        jPanel5.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, -1, -1));

        jLabel23.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel23.setText("TREASURER:");
        jLabel23.setAutoscrolls(true);
        jPanel5.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 240, -1, -1));

        jLabel24.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel24.setText("ASST. TREASURER:");
        jLabel24.setAutoscrolls(true);
        jPanel5.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 120, -1, -1));

        jLabel26.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel26.setText("P.R.O. :");
        jLabel26.setAutoscrolls(true);
        jPanel5.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 160, -1, -1));

        jLabel28.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel28.setText("AUDITOR:");
        jLabel28.setAutoscrolls(true);
        jPanel5.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 200, -1, -1));

        audtb.setEditable(false);
        audtb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                audtbActionPerformed(evt);
            }
        });
        jPanel5.add(audtb, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 200, 140, -1));

        prestb.setEditable(false);
        prestb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prestbActionPerformed(evt);
            }
        });
        jPanel5.add(prestb, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 120, 140, -1));

        vptb.setEditable(false);
        vptb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vptbActionPerformed(evt);
            }
        });
        jPanel5.add(vptb, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 160, 140, -1));

        sectb.setEditable(false);
        sectb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sectbActionPerformed(evt);
            }
        });
        jPanel5.add(sectb, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 200, 140, -1));

        trestb.setEditable(false);
        trestb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                trestbActionPerformed(evt);
            }
        });
        jPanel5.add(trestb, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 240, 140, -1));

        asttb.setEditable(false);
        asttb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                asttbActionPerformed(evt);
            }
        });
        jPanel5.add(asttb, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 120, 140, -1));

        protb.setEditable(false);
        protb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                protbActionPerformed(evt);
            }
        });
        jPanel5.add(protb, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 160, 140, -1));

        donebtn.setBackground(new java.awt.Color(0, 255, 51));
        donebtn.setFont(new java.awt.Font("Times New Roman", 1, 20)); // NOI18N
        donebtn.setText("DONE");
        donebtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                donebtnActionPerformed(evt);
            }
        });
        jPanel5.add(donebtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 310, 120, 40));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Materials/LIST.png"))); // NOI18N
        jLabel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel5.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 100, 90));

        jLabel22.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel22.setText("PRESIDENT:");
        jLabel22.setAutoscrolls(true);
        jPanel5.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, -1, -1));

        jLabel16.setFont(new java.awt.Font("Times New Roman", 0, 10)); // NOI18N
        jLabel16.setText("_____________________________________________________________________________________________");
        jPanel5.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 280, 480, 31));

        backbtn.setText("BACK");
        backbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbtnActionPerformed(evt);
            }
        });
        jPanel5.add(backbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 330, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 630, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 370, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void audtbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_audtbActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_audtbActionPerformed

    private void prestbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prestbActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_prestbActionPerformed

    private void vptbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vptbActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_vptbActionPerformed

    private void sectbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sectbActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sectbActionPerformed

    private void trestbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_trestbActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_trestbActionPerformed

    private void asttbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_asttbActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_asttbActionPerformed

    private void protbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_protbActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_protbActionPerformed

    private void donebtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_donebtnActionPerformed
        JOptionPane.showMessageDialog(null, "VOTING COMPLETE!"); 
        dispose(); 
        Choose ch = new Choose(); 
        ch.setVisible(true); 
    }//GEN-LAST:event_donebtnActionPerformed

    private void backbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbtnActionPerformed
        try {
            dispose();
            Ballot bl = new Ballot();
            bl.setVisible(true);
        } catch (SQLException ex) {
            Logger.getLogger(VoteList.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_backbtnActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VoteList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VoteList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VoteList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VoteList.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VoteList().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JTextField asttb;
    public javax.swing.JTextField audtb;
    private javax.swing.JButton backbtn;
    private javax.swing.JButton donebtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    public javax.swing.JPanel jPanel3;
    public javax.swing.JPanel jPanel5;
    public javax.swing.JTextField prestb;
    public javax.swing.JTextField protb;
    public javax.swing.JTextField sectb;
    public javax.swing.JTextField trestb;
    public javax.swing.JTextField vptb;
    // End of variables declaration//GEN-END:variables
}
